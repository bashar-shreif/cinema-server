<?php
require("../connection/connection.php");

$query = "CREATE TABLE snacks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    price DECIMAL(5,2)
);";

$execution = $mysqli->prepare($query);
$execution->execute();