<?php
require("../connection/connection.php");

$query = "CREATE TABLE movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    description TEXT,
    duration INT, -- in minutes
    rating VARCHAR(10), -- e.g. PG-13
    trailer_url VARCHAR(255),
    release_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);";

$execution = $mysqli->prepare($query);
$execution->execute();