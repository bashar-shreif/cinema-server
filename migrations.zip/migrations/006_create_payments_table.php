<?php
require("../connection/connection.php");

$query = "CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT,
    amount DECIMAL(6,2),
    payment_method VARCHAR(50),
    payment_date DATETIME,
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
);";

$execution = $mysqli->prepare($query);
$execution->execute();